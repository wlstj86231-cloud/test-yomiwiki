/**
 * YomiWiki Core Parser (V5.4 Fixed)
 * Decodes wiki markup into HTML with precision.
 */

function escapeHTML(str) {
    if (!str) return "";
    return str
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function wikiParse(content) {
    if (!content) return "";
    
    // --- 1. Collection Phase (Preserve special blocks before any escaping) ---
    const infoboxes = [];
    const clinicalBlocks = [];
    const codeBlocks = [];
    const SECRET_SALT = Math.random().toString(36).substring(7);

    // Code Blocks (Highest priority)
    content = content.replace(/```(\w+)?\n([\s\S]*?)```/g, (match, lang, code) => {
        const num = codeBlocks.length;
        codeBlocks.push(code.trim());
        return `%%%CODE_${num}_${SECRET_SALT}%%%`;
    });

    // Infobox
    content = content.replace(/\{\{infobox([\s\S]*?)\}\}/g, (match, body) => {
        const num = infoboxes.length;
        const rows = body.split('|').map(r => r.trim()).filter(r => r);
        let title = "ARCHIVAL_DATA";
        const data = [];
        rows.forEach(row => {
            if (row.includes('=')) {
                const parts = row.split('=');
                const key = parts[0].trim();
                const val = parts.slice(1).join('=').trim();
                if (key.toLowerCase() === 'title') title = val;
                else data.push({ key, val });
            }
        });
        infoboxes.push({ title, data });
        return `%%%INFOBOX_${num}_${SECRET_SALT}%%%`;
    });

    // Clinical Blocks
    content = content.replace(/\[CLINICAL\]([\s\S]*?)\[\/CLINICAL\]/g, (match, body) => {
        const num = clinicalBlocks.length;
        clinicalBlocks.push(body.trim());
        return `%%%CLINICAL_${num}_${SECRET_SALT}%%%`;
    });

    // --- 2. Security Escaping (Now safe because blocks are hidden) ---
    let html = escapeHTML(content);

    // --- 3. Text Formatting & Headers ---
    // Markdown Bold/Italic/Stroke
    html = html.replace(/\*\*(.*?)\*\*/g, '<b>$1</b>');
    html = html.replace(/__(.*?)__/g, '<b>$1</b>');
    html = html.replace(/(?<!\*)\*(?!\*)(.*?)(?<!\*)\*(?!\*)/g, '<i>$1</i>');
    html = html.replace(/(?<!_)_(?!_)(.*?)(?<!_)_(?!_)/g, '<i>$1</i>');
    html = html.replace(/~~(.*?)~~/g, '<del>$1</del>');

    const headers = [];
    const headerRegex = /^ *(#{1,6}) +(.+?)$|^ *(={2,}) *(.+?) *\3 *$/gm;
    html = html.replace(headerRegex, (match, hashes, mTitle, wikiHashes, wTitle) => {
        const level = hashes ? hashes.length : wikiHashes.length;
        const title = (mTitle || wTitle).trim();
        const id = "section-" + title.replace(/[_\s]+/g, '-').toLowerCase();
        headers.push({ level, title, id });
        return `<h${level} id="${id}">${title}</h${level}>`;
    });

    // --- 4. Footnotes (Precision Match) ---
    const footnotes = [];
    html = html.replace(/\[\* +(.+?)\]/g, (match, fnContent) => {
        const num = footnotes.length + 1;
        const cleanContent = fnContent.trim();
        footnotes.push(cleanContent);
        return `<sup><a id="fn-ref-${num}" href="#fn-${num}" class="footnote-link" data-tooltip="FOOTNOTE: ${cleanContent}">[${num}]</a></sup>`;
    });

    // --- Debug Stats ---
    console.log(`[PARSER_STATS]: Headers=${headers.length}, Footnotes=${footnotes.length}`);

    // --- 5. Links & Images (V4.1 Advanced) ---
    // Wiki Links (Data-Title for routing)
    html = html.replace(/\[\[([^|\]]+)\]\]/g, (match, title) => {
        const cleanTitle = title.trim();
        if (cleanTitle.toLowerCase().startsWith('category:')) return "";
        if (cleanTitle.startsWith('File:')) return match; 
        const slug = cleanTitle.replace(/ /g, '_'); // Consistent space-to-underscore
        return `<a href="/w/${encodeURIComponent(slug)}" class="wiki-link" data-title="${escapeHTML(cleanTitle)}">${escapeHTML(cleanTitle)}</a>`;
    });
    html = html.replace(/\[\[([^|\]]+)\|([^\]]+)\]\]/g, (match, title, alias) => {
        const cleanTitle = title.trim();
        const slug = cleanTitle.replace(/ /g, '_');
        return `<a href="/w/${encodeURIComponent(slug)}" class="wiki-link" data-title="${escapeHTML(cleanTitle)}">${escapeHTML(alias.trim())}</a>`;
    });

    html = html.replace(/\[\[File:([^|\]]+)(?:\|([^\]]+))?\]\]/g, (match, url, options) => {
        const params = {};
        if (options) {
            options.split('|').forEach(opt => {
                if (opt.includes('=')) {
                    const [key, val] = opt.split('=');
                    params[key.trim().toLowerCase()] = val.trim();
                } else params[opt.trim().toLowerCase()] = true;
            });
        }
        let alignClass = params.left ? "align-left" : (params.right ? "align-right" : (params.center ? "align-center" : ""));
        const widthStyle = params.width ? `width:${params.width};` : "";
        const caption = params.caption || "";
        return `<div class="media-container ${alignClass}" style="${widthStyle}"><img src="${encodeURI(url.trim())}" class="wiki-image" alt="${caption}">${caption ? `<div class="media-caption">${caption}</div>` : ''}</div>`;
    });

    html = html.replace(/\[(https?:\/\/[^\s\]]+)\s+([^\]]+)\]/g, '<a href="$1" class="external-link" target="_blank" rel="noopener noreferrer">$2</a>');
    
    // --- 6. Tables and Lists ---
    const lines = html.split('\n');
    let finalHtml = [];
    let listStack = [];
    let inTable = false;
    let tableHtml = "";
    
    lines.forEach(line => {
        const trimmed = line.trim();
        if (trimmed.startsWith('{|')) {
            inTable = true;
            tableHtml = '<table class="wikitable clinical-table">';
        } else if (trimmed.startsWith('|}')) {
            inTable = false;
            tableHtml += '</table>';
            finalHtml.push(tableHtml);
            tableHtml = "";
        } else if (inTable) {
            if (trimmed.startsWith('|+')) tableHtml += `<caption>${trimmed.substring(2).trim()}</caption>`;
            else if (trimmed.startsWith('|-')) tableHtml += '<tr>';
            else if (trimmed.startsWith('!')) {
                trimmed.substring(1).split('!!').forEach(c => {
                    const parts = c.split('|');
                    if (parts.length > 1 && parts[0].includes('=')) {
                        tableHtml += `<th ${parts[0].trim()}>${wikiParse(parts.slice(1).join('|').trim())}</th>`;
                    } else {
                        tableHtml += `<th>${wikiParse(c.trim())}</th>`;
                    }
                });
            }
            else if (trimmed.startsWith('|')) {
                trimmed.substring(1).split('||').forEach(c => {
                    const parts = c.split('|');
                    // Check if the first part is an attribute (contains =)
                    if (parts.length > 1 && parts[0].includes('=')) {
                        tableHtml += `<td ${parts[0].trim()}>${wikiParse(parts.slice(1).join('|').trim())}</td>`;
                    } else {
                        tableHtml += `<td>${wikiParse(c.trim())}</td>`;
                    }
                });
            }
        } else {
            const listMatch = line.match(/^([\*\#]+)\s*(.*)$/);
            if (listMatch) {
                const prefix = listMatch[1];
                const depth = prefix.length;
                const type = prefix[depth-1] === '*' ? 'ul' : 'ol';
                while (listStack.length > depth) finalHtml.push(`</${listStack.pop()}>`);
                while (listStack.length < depth) { listStack.push(type); finalHtml.push(`<${type}>`); }
                finalHtml.push(`<li>${listMatch[2]}</li>`);
            } else {
                while (listStack.length > 0) finalHtml.push(`</${listStack.pop()}>`);
                if (trimmed.startsWith('----')) finalHtml.push('<hr>');
                else if (line.trim()) finalHtml.push(line + '<br>');
            }
        }
    });
    let parsedContent = finalHtml.join('');

    // --- 7. TOC Generation (INTEGRATED) ---
    if (headers.length >= 1) { // Lowered from 3 for debugging/validation
        const counts = [0, 0, 0, 0, 0, 0, 0];
        let lastLevel = 0;
        let tocHtml = `<div class="wiki-toc"><div class="toc-title">CONTENTS <span class="toc-toggle" onclick="window.toggleTOC()">[hide]</span></div><ul id="toc-list">`;
        headers.forEach(h => {
            if (h.level < lastLevel) for (let i = h.level + 1; i < counts.length; i++) counts[i] = 0;
            counts[h.level]++;
            lastLevel = h.level;
            const numberStr = counts.slice(1, h.level + 1).filter(n => n > 0).join('.') + '.';
            tocHtml += `<li class="toc-level-${h.level}"><a href="#${h.id}"><span class="toc-number">${numberStr}</span> ${h.title}</a></li>`;
        });
        tocHtml += `</ul></div>`;
        parsedContent = tocHtml + parsedContent;
    }

    // --- 8. Footnote List Injection ---
    if (footnotes.length > 0) {
        let fnHtml = `<div class="wiki-footnotes"><div class="footnotes-title">[ARCHIVAL_FOOTNOTES]</div><ol>`;
        footnotes.forEach((content, i) => {
            const num = i + 1;
            fnHtml += `<li id="fn-${num}">${wikiParse(content)} <a href="#fn-ref-${num}" class="footnote-backlink">↩</a></li>`;
        });
        fnHtml += `</ol></div>`;
        parsedContent += fnHtml;
    }

    // --- 9. Injection Phase (Restore special blocks) ---
    parsedContent = parsedContent.replace(/%%%INFOBOX_(\d+)_([a-z0-9]+)%%%/g, (match, num, salt) => {
        if (salt !== SECRET_SALT) return match;
        const info = infoboxes[num];
        let bodyHtml = "";
        info.data.forEach(item => {
            const key = item.key.toLowerCase();
            if (key === 'image') bodyHtml += `<tr><td colspan="2" class="infobox-image-cell"><img src="${encodeURI(item.val)}" class="wiki-image"></td></tr>`;
            else if (key === 'caption') bodyHtml += `<tr><td colspan="2" class="infobox-caption-cell">${item.val}</td></tr>`;
            else bodyHtml += `<tr><th>${item.key}</th><td>${wikiParse(item.val)}</td></tr>`;
        });
        return `<aside class="infobox"><div class="infobox-title">${info.title}</div><table>${bodyHtml}</table></aside>`;
    });

    parsedContent = parsedContent.replace(/%%%CLINICAL_(\d+)_([a-z0-9]+)%%%/g, (match, num, salt) => {
        if (salt !== SECRET_SALT) return match;
        return `<div class="clinical-report-block"><div class="clinical-report-header">[OFFICIAL_CLINICAL_RECORD]</div><div class="clinical-report-content">${wikiParse(clinicalBlocks[num])}</div><div class="clinical-report-footer">VALIDATED_BY_ARCHIVE_SYSTEM</div></div>`;
    });

    parsedContent = parsedContent.replace(/%%%CODE_(\d+)_([a-z0-9]+)%%%/g, (match, num, salt) => {
        if (salt !== SECRET_SALT) return match;
        return `<pre class="wiki-code"><code>${escapeHTML(codeBlocks[num])}</code></pre>`;
    });

    return parsedContent;
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { wikiParse, escapeHTML };
}
